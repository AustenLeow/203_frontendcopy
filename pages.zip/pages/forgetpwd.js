import React from 'react'

export default function forgetpwd() {
  return (
    // follow order of previous pages 
    <div>forgetpwd</div>
  )
}
